import 'package:flutter/cupertino.dart';

class RadioView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Radio View",
          style: TextStyle(
            fontSize: 50,
            fontWeight: FontWeight.bold,
            fontFamily: "ElMessiri",
          )),
    );
  }
}
