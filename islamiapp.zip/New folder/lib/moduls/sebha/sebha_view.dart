import 'package:flutter/cupertino.dart';

class SebhaView extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text("Sebha View",
          style: TextStyle(
            fontSize: 50,
            fontWeight: FontWeight.bold,
            fontFamily: "ElMessiri",
          )),
    );
  }
}
